import React from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { Feed } from './components/Feed';
import { TrendingTopics } from './components/TrendingTopics';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="container mx-auto px-4 py-6 max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-3">
            <Sidebar />
          </div>
          <div className="lg:col-span-6">
            <Feed />
          </div>
          <div className="lg:col-span-3">
            <TrendingTopics />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;