import { useState } from 'react';

export interface Post {
  id: string;
  type: 'text' | 'image' | 'video' | 'link';
  content: string;
  author: string;
  timestamp: string;
  verified?: boolean;
  media?: string;
  url?: string;
  likes: number;
  isLiked: boolean;
}

export function usePost() {
  const [posts, setPosts] = useState<Post[]>([
    {
      id: '1',
      type: 'image',
      content: '¡Explorando nuevos lugares! 🌎✨',
      author: 'María González',
      timestamp: 'Hace 2 horas',
      verified: true,
      media: 'https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?auto=format&fit=crop&q=80',
      likes: 234,
      isLiked: false,
    },
    {
      id: '2',
      type: 'text',
      content: 'La tecnología está transformando la manera en que vivimos y trabajamos. ¿Qué opinan sobre la inteligencia artificial y su impacto en nuestra sociedad? 🤖💭',
      author: 'Carlos Tech',
      timestamp: 'Hace 3 horas',
      verified: true,
      likes: 156,
      isLiked: false,
    },
    {
      id: '3',
      type: 'link',
      content: '¡Nuevo artículo sobre desarrollo web! No te pierdas estos consejos fundamentales para mejorar tus habilidades.',
      author: 'Dev Community',
      timestamp: 'Hace 5 horas',
      url: 'https://dev.to',
      likes: 89,
      isLiked: false,
    }
  ]);

  const toggleLike = (postId: string) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          likes: post.isLiked ? post.likes - 1 : post.likes + 1,
          isLiked: !post.isLiked
        };
      }
      return post;
    }));
  };

  const addPost = (newPost: Omit<Post, 'id' | 'timestamp' | 'likes' | 'isLiked'>) => {
    const post: Post = {
      ...newPost,
      id: Date.now().toString(),
      timestamp: 'Ahora',
      likes: 0,
      isLiked: false,
    };
    setPosts([post, ...posts]);
  };

  return { posts, toggleLike, addPost };
}