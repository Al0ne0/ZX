import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface User {
  id: string;
  name: string;
  username: string;
  avatar?: string;
  bio?: string;
  email: string;
  notifications: boolean;
  darkMode: boolean;
  language: 'es' | 'en';
  privacy: {
    profileVisibility: 'public' | 'private';
    showOnline: boolean;
  };
}

interface AuthState {
  user: User | null;
  updateUser: (data: Partial<User>) => void;
  updatePrivacy: (privacy: Partial<User['privacy']>) => void;
  updatePreferences: (preferences: { notifications?: boolean; darkMode?: boolean; language?: 'es' | 'en' }) => void;
}

export const useAuth = create<AuthState>()(
  persist(
    (set) => ({
      user: {
        id: '1',
        name: 'Usuario Actual',
        username: '@usuario',
        email: 'usuario@ejemplo.com',
        notifications: true,
        darkMode: false,
        language: 'es',
        privacy: {
          profileVisibility: 'public',
          showOnline: true,
        },
      },
      updateUser: (data) =>
        set((state) => ({
          user: state.user ? { ...state.user, ...data } : null,
        })),
      updatePrivacy: (privacy) =>
        set((state) => ({
          user: state.user
            ? {
                ...state.user,
                privacy: { ...state.user.privacy, ...privacy },
              }
            : null,
        })),
      updatePreferences: (preferences) =>
        set((state) => ({
          user: state.user ? { ...state.user, ...preferences } : null,
        })),
    }),
    {
      name: 'auth-storage',
    }
  )
);