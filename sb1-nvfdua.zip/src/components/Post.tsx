import React, { useState } from 'react';
import { Link2, MessageCircle, Heart, Share2, CheckCircle } from 'lucide-react';
import type { Post as PostType } from '../hooks/usePost';

interface PostProps extends PostType {
  onLike: () => void;
}

export function Post({ type, content, author, timestamp, verified, media, url, likes, isLiked, onLike }: PostProps) {
  const [isCommentOpen, setIsCommentOpen] = useState(false);

  const handleShare = async () => {
    try {
      await navigator.share({
        title: 'Compartir publicación',
        text: content,
        url: window.location.href
      });
    } catch (error) {
      console.log('Error compartiendo:', error);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-md p-6 mb-6">
      <div className="flex items-center mb-4">
        <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
          <span className="text-white font-bold">{author[0].toUpperCase()}</span>
        </div>
        <div className="ml-4">
          <div className="flex items-center">
            <h3 className="font-semibold text-lg">{author}</h3>
            {verified && (
              <CheckCircle className="w-5 h-5 text-blue-500 ml-2" />
            )}
          </div>
          <p className="text-gray-500 text-sm">{timestamp}</p>
        </div>
      </div>

      <p className="text-gray-800 mb-4">{content}</p>

      {type === 'image' && media && (
        <div className="rounded-lg overflow-hidden mb-4">
          <img src={media} alt="Post content" className="w-full h-auto" />
        </div>
      )}

      {type === 'video' && media && (
        <div className="rounded-lg overflow-hidden mb-4">
          <video controls className="w-full">
            <source src={media} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        </div>
      )}

      {type === 'link' && url && (
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="block bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity mb-4"
        >
          Visitar Enlace <Link2 className="inline-block w-4 h-4 ml-2" />
        </a>
      )}

      <div className="flex items-center justify-between text-gray-500 pt-4 border-t">
        <button
          onClick={onLike}
          className={`flex items-center gap-2 transition-colors ${
            isLiked ? 'text-pink-500' : 'hover:text-pink-500'
          }`}
        >
          <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
          <span>{likes}</span>
        </button>
        <button
          onClick={() => setIsCommentOpen(!isCommentOpen)}
          className="flex items-center gap-2 hover:text-blue-500 transition-colors"
        >
          <MessageCircle className="w-5 h-5" />
          <span>Comentar</span>
        </button>
        <button
          onClick={handleShare}
          className="flex items-center gap-2 hover:text-green-500 transition-colors"
        >
          <Share2 className="w-5 h-5" />
          <span>Compartir</span>
        </button>
      </div>

      {isCommentOpen && (
        <div className="mt-4 pt-4 border-t">
          <textarea
            placeholder="Escribe un comentario..."
            className="w-full p-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
            rows={2}
          />
          <button className="mt-2 px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors">
            Comentar
          </button>
        </div>
      )}
    </div>
  );
}