import React from 'react';
import { CreatePost } from './CreatePost';
import { Post } from './Post';
import { usePost } from '../hooks/usePost';

export function Feed() {
  const { posts, toggleLike, addPost } = usePost();

  return (
    <div className="space-y-6">
      <CreatePost onPost={addPost} />
      {posts.map((post) => (
        <Post key={post.id} {...post} onLike={() => toggleLike(post.id)} />
      ))}
    </div>
  );
}